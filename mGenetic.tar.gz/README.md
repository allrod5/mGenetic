# mGenetic
Modular Genetic Algorithm

this is a project of our artificial intelligence undergraduate course in ufabc.
we're comparing genetic algorithms using python and stuff.
