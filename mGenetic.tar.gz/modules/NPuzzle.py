import global_settings as this

def populate():
	this.int_a = int(input("Board size: "))
	this.population = []
	this.fitness = []

def check(array):


def stopCriteria():

